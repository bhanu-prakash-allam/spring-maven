package com.cts.springboot.boothibernet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoothibernetApplicationTests {

	@Test
	void contextLoads() {
	}

}
