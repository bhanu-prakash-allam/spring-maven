package com.cts.springboot.boothibernet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoothibernetApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoothibernetApplication.class, args);
	}

}
